<?php
// Не забудьте поменять данные
return [
	// 'host' => 'server144.hosting.reg.ru',
	// 'dbname' => 'u1581388_testplace',
	// 'login' => 'u1581388_admin',
	// 'password' => '12971297test'

	'host' => 'localhost',
	'dbname' => 'xnbafka8_data',
	'login' => 'xnbafka8_test',
	'password' => 'FUm(;e%LwFFt'
];
